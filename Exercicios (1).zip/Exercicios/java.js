let resposta = document.getElementById('resposta')
function calcular(){
    let resultado = 5 + 3 * 4 - 8 / 2
    console.log (resultado)
    resposta.innerHTML = "O valor é " + resultado
    resposta.style.fontSize ='30px'
}

let resposta1 = document.getElementById('resposta1')
function calcular1(){
    let resultado1 = 9 - 4 * (9 / 3) + (6 / 2)
    console.log(resultado1)
    resposta1.innerHTML ='O valor é ' + resultado1
    resposta1.style.fontSize ='30px'
}

let resposta2 = document.getElementById('resposta2')
function calcular2(){
    let resultado2 = 5.5 + 3.3 / 2.0 * 4.8 + 6.1
    console.log(resultado2)
    resposta2.innerHTML ='O valor é ' + resultado2
    resposta2.style.fontSize ='30px'
}

let resposta3 = document.getElementById('resposta3')
function calcular3(){
    let resultado3 = 7.9 * 3.2 + 5.2 / 3.1 + 7.9
    console.log(resultado3)
    resposta3.innerHTML ='O valor é ' + resultado3
    resposta3.style.fontSize ='30px'
}







